#pragma once

enum class Direction 
{
    UP = 0,
    RIGHT = 1,
    DOWN = 2,
    LEFT = 3,
    STAY = 4
};
 